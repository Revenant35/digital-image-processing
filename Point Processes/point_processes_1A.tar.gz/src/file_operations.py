from pathlib import Path
import cv2 as cv


def save_image(image, path):
    cv.imwrite(path, image)
    return


def open_image(path):
    return cv.imread(path)


def show_image(image, title):
    cv.imshow(title, image)
    cv.waitKey(0)
    cv.destroyAllWindows()


def get_image_folder():
    folder = Path(__file__).parents[1].joinpath("images").resolve()
    assert folder.exists()
    return folder
